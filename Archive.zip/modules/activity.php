<div class="card-body">
  <h5 class="card-title">Recent Activity</h5>

  <div class="activity">

    <div class="activity-item d-flex">
      <div class="activite-label">16/11/2022</div>
      <i class='bi bi-circle-fill activity-badge text-success align-self-start'></i>
      <div class="activity-content">
        Launched Base64 Tools
      </div>
    </div><!-- End activity item-->

    <div class="activity-item d-flex">
      <div class="activite-label">16/11/2022</div>
      <i class='bi bi-circle-fill activity-badge text-success align-self-start'></i>
      <div class="activity-content">
        Launched God Tools
      </div>
    </div><!-- End activity item-->

  </div>

</div>
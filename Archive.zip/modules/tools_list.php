<!-- Encode & Decode Tools Card -->
<div class="card info-card sales-card">

  <div class="card-body">
    <h5 class="card-title">Encode & Decode <span> Tools</span></h5>

    <div class="tools-box-grid">

      <div class="d-flex align-items-center grid-tools">
        <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
          <i class="bi bi-repeat"></i>
        </div>
        <div class="ps-3">
          <h6>Base64</h6>
          <span class="text-success medium pt-1 fw-bold">Encode</span>
        </div>
      </div>

      <div class="d-flex align-items-center grid-tools">
        <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
          <i class="bi bi-repeat"></i>
        </div>
        <div class="ps-3">
          <h6>Base64</h6>
          <span class="text-success medium pt-1 fw-bold">Decode</span>
        </div>
      </div>

  </div>

  </div>

</div>
<!-- Encode & Decode Tools Card -->


<!-- Javascript Tools Card -->
<div class="card info-card sales-card">

  <div class="card-body">
    <h5 class="card-title">Javascript <span> Tools</span></h5>

    <div class="tools-box-grid">

      <div class="d-flex align-items-center grid-tools">
        <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
          <i class="bi bi-filetype-js"></i>
        </div>
        <div class="ps-3">
          <h6>Javascript</h6>
          <span class="text-success medium pt-1 fw-bold">Minify</span>
        </div>
      </div>

      <div class="d-flex align-items-center grid-tools">
        <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
          <i class="bi bi-filetype-js"></i>
        </div>
        <div class="ps-3">
          <h6>Javascript</h6>
          <span class="text-success medium pt-1 fw-bold">Beautify</span>
        </div>
      </div>

      <div class="d-flex align-items-center grid-tools">
        <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
          <i class="bi bi-filetype-js"></i>
        </div>
        <div class="ps-3">
          <h6>Javascript</h6>
          <span class="text-success medium pt-1 fw-bold">Obfuscator</span>
        </div>
      </div>


  </div>

  </div>

</div>
<!-- End Javascript Tools Card -->